
var innovaphone = innovaphone || {};
innovaphone.jsbadgeexampleTexts = {
    en: {
    },
    de: {
    }
}
